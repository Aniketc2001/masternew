import React from 'react'

export default function NotFound() {
  return (
    <div>
      This Page is not found...
    </div>
  )
}
