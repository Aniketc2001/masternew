import React from 'react'

export default function SystemUserList() {
  return (
    <div>
      Hello from System User List
    </div>
  )
}
